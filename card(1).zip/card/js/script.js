
$(function () {
	// 订单确认页 支付方式状态切换
	$('.zfStatus').on('click', 'i',function () {
		$(this).addClass('cur').siblings('i').removeClass('cur');
	})
})