// 首页的内容
$(function () {
	var html = '';
	$.ajax({
		type: 'GET',
		url: 'http://192.168.1.7:8080/js/json.json',
		success: function (data) {
			if (data != []) {
				$.each(data, function (index, val) {
					html += '<tr>\
								<td>\
									<div align="left"> \
										<a class="button" title="自动发货商品，购买后自动发货">自动</a>\
										<font size="3" title="'+data[index].Title+'">'+data[index].Title+'</font>\
									</div>\
								</td>\
								<td>\
									<font color="#FF5400" size="2" title="会员单价">'+data[index].Price+'元</font>\
								</td>\
								<td>\
									<font color="#0281D2" size="2" title="批发单价">'+data[index].WapPrice+'元</font>\
									<br>\
									<font color="#BBBBBB" size="1" title="普通用户购买数量1个起按照批发单价计算">'+data[index].ShowNumber+'个起</font> \
								</td>\
								<td>\
									<a href="goumai.html" class="goumai">购买</a>\
								</td>\
							</tr>';
				})
				$('.table').find('tbody').html(html);
			}
		}
	})
})