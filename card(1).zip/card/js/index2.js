$(function () {
	// 首页 右侧表格数据
	var htmlPage = new Vue({
		el: '#wrap',
		data: {
			tableData: [],  // 表格数据
			orderInfo: {},  // 购买详情数据
		},
		mounted() {
			this.getTablelist();
		},
		methods: {
			getTablelist () {  // 首页右侧表格数据
				var that = this;
				$.ajax({
					type: 'GET',
					url: 'http://192.168.1.7:8080/js/json.json?t='+Math.random(),
					success: function (data) {
						if (data != []) {
							that.tableData = data;
						}
					}
				})
			},
			getGoumai(val) {  // 点击首页表格购买按钮
				window.location.href = 'goumai.html?id='+val;
			},
			getOrderinfo () { // 从首页点击购买进去购买页 获取信息接口
				var that = this;
				$.ajax({
					type: 'GET',
					url: 'http://192.168.1.7:8080/js/json1.json?t='+Math.random(),
					success: function (data) {
						if (data) {
							that.orderInfo = data;
							console.log(data);
						}
					}
				})
			}
		}
	})
})