$(function () {
	// 首页 右侧表格数据
	var htmlPage = new Vue({
		el: '#wrap',
		data: {
			orderInfo: {},  // 购买详情数据
			idVal: '',
			phone: '',   // 手机号
			number: 1,  // 购买数量
			error: '请输入手机号',
			isError: false,  // 是否显示错误提示
		},
		created() {
			this.idVal = this.getUrlKey('id');
		},
		mounted() {
			this.getOrderinfo();
		},
		methods: {
			getUrlKey (name) {
				return decodeURIComponent((new RegExp('[?|&]'+name+'='+'([^&;]+?)(&|#|;|$)').exec(location.href)||[,""])[1].replace(/\+/g,'%20'))||null;
			},
			getOrderinfo () { // 从首页点击购买进去购买页 获取信息接口
				var that = this;
				$.ajax({
					type: 'GET',
					url: 'http://192.168.1.7:8080/js/json1.json?id='+that.idVal+'&t='+Math.random(),
					success: function (data) {
						if (data) {
							that.orderInfo = data;
						}
					}
				})
			},
			purchaseFn () {  // 点击游客购买
				var rag = /^1[3578][0-9]{9}$/g;
				if (this.phone == '') {
					this.isError = true;
					this.error = '请输入手机号';
				} else if (!rag.test(this.phone)) {
					this.isError = true;
					this.error = '手机号格式错误';
				} else if (this.number > this.orderInfo.Stock) {
					$('.messageInfo').show().html('库存不够').fadeOut(2000);
					return false;
				} else { // 跳转到下单页
					window.location.href = 'placeOrder.html?phone='+this.phone;
				}
			}
		}
	})
})