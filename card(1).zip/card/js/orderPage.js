$(function () {
	// 订单页
	var htmlPage = new Vue({
		el: '#wrap',
		data: {
			tableData: [],  // 表格数据
			orderInfo: {},  // 购买详情数据
		},
		mounted() {
			this.getTablelist();
		},
		methods: {
			getTablelist () {  // 右侧表格数据
				var that = this;
				$.ajax({
					type: 'GET',
					url: 'http://192.168.1.7:8080/js/json.json?t='+Math.random(),
					success: function (data) {
						if (data != []) {
							that.tableData = data;
						}
					}
				})
			},
			showStaus(val) {  // 点击每一行的状态已发货
				$('#model1').fadeIn(600);   // 显示状态弹窗
			},
			closeModel () { // 点击弹窗关闭按钮
				$('.model').fadeOut(500);  // 关闭弹窗
			},
			getCard(val) { // 点击每一行的提取按钮
				$('#model2').fadeIn(600); 
			}
		}
	})
})